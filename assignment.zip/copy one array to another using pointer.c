#include<stdio.h>

int main(){
    int arr[]={1,2,3,4,5};
    int arr1[5];
    int *ptr1;
    printf("before coping...\n");
    printf("From \t To\n");
    int i;

    ptr1=&arr;

    for(i=0;i<5;i++){
        printf("%d \t %d \n",*(ptr1+i),arr1[i]);
    }
    for(i=0;i<5;i++){
        arr1[i]=*(ptr1+i);
    }
    printf("\n\n after coping...\n");
    printf("From \t To\n");
    for(i=0;i<5;i++){
        printf("%d \t %d \n",*(ptr1+i),arr1[i]);
    }
    return 0;
}
