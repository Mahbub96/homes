#include<stdio.h>
#include<string.h>
#include<conio.h>

void swap(int *arr1,int *arr2){
    int temp;
    temp=&arr1;
    arr1=arr2;
    arr2=temp;



}



int main(){
    int arr1[5]={5,4,3,2,1};
    int arr2[5]={1,2,3,4,5};
    int i,n=5;


    printf("\n\n\n before swap 1st array:");
    for(i=0;i<n;i++)
        printf("%d , ",arr1[i]);

    printf("\n\n\n before swap 2nd array:");
    for(i=0;i<n;i++)
        printf("%d , ",arr2[i]);

    printf("\n\n\n");



    swap(&arr1,&arr2);

    printf("\n\n\n After swap 1st array:");
    for(i=0;i<n;i++)
        printf("%d , ",arr1[i]);

    printf("\n\n\n After swap 2nd array:");
    for(i=0;i<n;i++)
        printf("%d , ",arr2[i]);

        printf("\n\n\n\n");

    return 0;
}
