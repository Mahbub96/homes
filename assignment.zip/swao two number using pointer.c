#include<stdio.h>

void swap(int *a,int *b){
    int temp;
    temp=*a;
    *a=*b;
    *b=temp;

}

int main(){
    int a=20;
    int b=12;
    printf(" Before swap:a=%d and b=%d",a,b);
    swap(&a,&b);
    printf("\n after swap:a=%d and b=%d",a,b);
    return 0;
}

